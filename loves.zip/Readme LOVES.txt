Hello,

Thank for downloading LOVES



NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 


Paypal account for donation : https://www.paypal.me/mlkwsn

Link to purchase full version and commercial license:

Please visit our store for more great fonts : 

https://crmrkt.com/d1W2GB




If there is a problem, question, or anything about my fonts, please sent an email to

mlkwsn999@gmail.com




Thanks,

MLKWSN Studios